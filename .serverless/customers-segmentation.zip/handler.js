'use strict';
const mongoose = require('mongoose');
require('mongoose').set('debug', true);
const allianceModel = require('./models/Alliance');
const parametersModel = require('./models/Parameters');
const reportResultsModel = require('./models/Report_Result');
const constants= require('./functions/Contants');

var alliancesFunctions = require('./functions/alliancesFunctions');
var parametersFuntions = require('./functions/parametersFunctions');
var tripsFunctions = require('./functions/tripsFunctions');
var ObjectID = mongoose.Types.ObjectId;

function getObjectIdsList(arr) {
    var newArr = [];
    for(var i = 0; i<arr.length; i++){
        newArr[i] = ObjectID(arr[i]);
    }
    return newArr;
}




module.exports.generateReports = (event, context, callback) => {
  return callback( false,searchForReports());

/*
    const response = {
        statusCode: 200,
        body: JSON.stringify({
            message: 'Go Serverless v1.0! Your function executed successfully!',
            input: event,
        }),
    };

    callback(null, response);*/
};


async function searchForReports(){

    try {
   /*1st Step----------------------------Reports Collection Dropping */
  var dbConnection=mongoose.connect(constants.DB, { useNewUrlParser: true});
  console.log("Mongoose connected a ready to use "+mongoose.connection.readyState);
  /*2nd Step----------------------------Reports Collection Dropping */
  reportResultsModel.collection.countDocuments(function (err, count) {
      if (!err && count > 0) {
        reportResultsModel.collection.drop();
      }
  });
  
  /*3rd Step----------------------------Reports Collection Dropping */
  let availableReports=await parametersModel.find().exec();
 


   /*4th Step----------------------------All reports processing */
  for(var i=0;i<availableReports.length;i++){
    let result=await processReport(availableReports[i]);
    await parametersFuntions.saveReport(result,availableReports[i]._id);
  }

  /*5th Step----------------------------Close connection*/


  console.log("STATUS BEFORE CLOSING********************************"+mongoose.connection.readyState);
    mongoose.connection.close(function(err){
  if(err) console.log("Errors disconnection from MONGODB STATUS="+mongoose.connection.readyState+" ERROR="+err)
  console.log("Mongoose default connection was disconnected successfully STATUS="+mongoose.connection.readyState);
});

} catch(err) {
    console.log(err)
}
  return "TH";

}

async function processReport(individualReport) {
      individualReport=JSON.parse(JSON.stringify(individualReport));
       var parametersReportType=individualReport.report_type;
       var parametersFromNumber=individualReport.from_number;
       var parametersToNumber=individualReport.to_number;
       var parametersStartDate=individualReport.from_date;
       var parametersEndDate=individualReport.to_date;
       var parametersQueryLimit=individualReport.results_limit;
       var parametersUsersIDs=getObjectIdsList(individualReport.param_ids);
       
      if(parametersReportType==='A1'){
        return tripsFunctions.getReportUsersTripsByUsersId(parametersStartDate,parametersEndDate,parametersUsersIDs,parametersQueryLimit,parametersFromNumber,parametersToNumber);
      }

      else if(parametersReportType==='A2'){
          /*console.log("PARAMETERSB-------"+parametersStartDate+"---"+parametersEndDate);*/
        return tripsFunctions.getReportUsersTripsAllUsers(parametersStartDate,parametersEndDate,parametersQueryLimit,parametersFromNumber,parametersToNumber);
      }
}