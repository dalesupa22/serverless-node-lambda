'use strict';
const mongoose = require('mongoose');
require('mongoose').set('debug', true);


const userModel = require('../models/User');
const tripsModel = require('../models/Trip');
const allianceModel = require('../models/Alliance');

var ObjectID = mongoose.Types.ObjectId;
var moment=require('moment-timezone');



module.exports = {
      getAlliancesUserWithRange: function getAlliancesUserWithRange() {
          return allianceModel.aggregate([
          {  
              $lookup:{  
                from:"59dbe679f87e564d77b41e7b_miaguila_users",
                localField:"_id",
                foreignField:"alliance_id",
                as:"xxxxxxxxxxx"
              }
          },
            { $unwind: "$xxxxxxxxxxx" }/*Decouple result*/, 
            {  
              $group:{  
                _id:"$xxxxxxxxxxx.alliance_id",
                count:{  
                    $sum:1
                }
              }
          }
          ,   {$match : {$and : [{count : {"$lt" : 5}},{count: {"$gt" : 3}}]}}
        ]).exec();
        }
  }


