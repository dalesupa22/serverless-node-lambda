'use strict';
const mongoose = require('mongoose');
require('mongoose').set('debug', true);


const userModel = require('../models/User');
const tripsModel = require('../models/Trip');
const allianceModel = require('../models/Alliance');
const parametersModel = require('../models/Parameters');
const reportResultsModel = require('../models/Report_Result');

const mongoString = 'mongodb://miaguila:RZxVxZNMnwj8ms9H@52.204.156.26:27017/modules'; // MongoDB Url
var ObjectID = mongoose.Types.ObjectId;

module.exports = {
  saveReport: async function saveReport(reportContent,reportid) {
      if(reportContent!==undefined){
           /*Report ID setting*/
          for(var k=0;reportContent.length;k++){
            if(reportContent[k]!==undefined){
              reportContent[k].report_id=reportid;
              }else{
                break;
              }
          }

          /*Report Results Insertion console.log("RESULT---------------------"+reportContent);*/
          reportResultsModel.collection.insertMany(reportContent,function(err,reportContent){
            if(err){
              return console.error(err+"ERROR ERROR ERROR ERROR ERROR STORING");
            }else{
              console.log("Multiple Documents Saved");
            }
          })
        }
    }
    
  
}