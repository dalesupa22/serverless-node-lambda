require('dotenv').config({ path: './variables.env' });

const QUERY_LIMIT=process.env.QUERY_LIMIT;
const FROM_NUMBER=process.env.FROM_NUMBER;/*Default From Number */
const TO_NUMBER=process.env.TO_NUMBER;/*Default From Number */
const FROM_DATE=process.env.FROM_DATE;
const COLLECTIONS_ID=process.env.COLLECTIONS_ID;/*DEV 59dbe679f87e564d77b41e7b_ PROD 594157dcd5a84a7e8fc93627_*/
const DB = process.env.DB; // MongoDB Url
module.exports={
    QUERY_LIMIT:QUERY_LIMIT,
    DB:DB,
    FROM_NUMBER:FROM_NUMBER,
    TO_NUMBER:TO_NUMBER,
    FROM_DATE:FROM_DATE,
    COLLECTIONS_ID:COLLECTIONS_ID
};