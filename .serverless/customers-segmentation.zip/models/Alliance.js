const mongoose = require('mongoose');
const constants = require('../functions/Contants');


var schemaOptions = {
  timestamps: true,
  toJSON: {
    virtuals: true
  },
  collection: constants.COLLECTIONS_ID+'miaguila_alliances'
};


var allianceSchema = new mongoose.Schema({
  updatedAt: Date,
  createdAt: Date,
  active: Boolean,
  service_trip:{
    automatic_reservation_assignment : Boolean,
    know_driver : Boolean
  },
  pool:Array,
  pool_active:Boolean,
  restrictions:Array,
  restrictions_block:Boolean,
  budget:{
    block : Boolean,
    mount_alert : Number,
    mount : Number
  },
  top_value:Number,
  top:Number,
  info:{
    image : String,
    label : String,
    alert : Number,
    invoice_start : Number,
    estimate : Number,
    type_alliance : String,
    credit_days : Number,
    type_payment : String
  },
  swap:Number,
  balance:Number,
  price:{
    comission_alliance_percentage : Number,
    alliance_discounts : Number,
    feed_trip : Number,
    feed_admin : Number,
    add_all : Number,
    driver_discounts : Number
  },
  legal:{
    document_number_contact : String,
    document_type_contact : String,
    email_contact : String,
    phone_contact : String,
    name_contact : String,
    document_number_representative : String,
    document_type_representative : String,
    email_representative : String,
    phone_representative : String,
    name_representative : String,
    email : String,
    phone : Array,
    address : String,
    nit : String,
    name : String
  },
  contract:{
    number : Number
  },
  kam_ids:Array,
  salesman_ids:Array,
  admins_ids:Array,
  regions_ids:Array,
  country_id:String,
  domains:Array,
  alliance_father_id:String
}, schemaOptions);

module.exports =mongoose.models.Alliance|| mongoose.model('Alliance', allianceSchema);