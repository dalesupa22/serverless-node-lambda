const mongoose = require('mongoose');
const constants = require('../functions/Contants');

var schemaOptions = {
  timestamps: true,
  toJSON: {
    virtuals: true
  },
  collection: constants.COLLECTIONS_ID+'miaguila_trips'
};


var tripSchema = new mongoose.Schema({
  updatedAt: Date,
  createdAt: Date,
  active: Boolean,
  minutes_until_assignment : String,
	type_payment : String,
	driver_working : String,
	logs : [
		{
			date : Date,
			agent_id : String,
			subject : String,
			message : String
		}
	],
	trips : Array,
	agents : Array,
	service_trip : {
		automatic_reservation_assignment : Boolean,
		places : Number,
		pool : Boolean,
		know_driver : Boolean,
		reassigned : Boolean,
		instantly : Boolean,
		link_trip : Boolean,
		automatically_assigned : Boolean
	},
	notifications : Array,
	charges : {
		fixed_rate : Number,
		minimum : Number,
		night : Number,
		base_end : Number,
		base_start : Number,
		tracks_value : Number,
		name : String
	},
	statistics : {
		time : Number,
		distance : Number
	},
	tracks : Array,
	fix_price : Array,
	price : {
		estimate_total : Number,
		add_all : Number,
		premium : Number,
		reward_obj : String,
		reward : Number,
		promo_code : String,
		promo : Number,
		comments_driver : String,
		comments_user : String,
		admin_id : String,
		user_total : Number,
		user_subtotal : Number,
		ma_total : Number,
		ma_subtotal : Number,
		alliance_total : Number,
		alliance_subtotal : Number,
		comission_ma_alliance : Number,
		comission_ma_alliance_percentage : Number,
		comission_alliance : Number,
		comission_alliance_percentage : Number,
		feed_trip : Number,
		feed_trip_percentage : Number,
		driver_discounts : Number,
		driver_discounts_percentage : Number,
		discounts : Number,
		discounts_percentage : Number,
		driver_subtotal : Number,
		driver_total : Number,
		comission_ma : Number,
		comission_ma_percentage : Number,
		trip : Number,
		sub_trip_adjustment : Number,
		sub_trip : Number,
		stop_value : Number,
		stops : Number
	},
	path : String,
	end : {
		zone_id : String,
		real_location : String,
		real_address : String,
		pickup_location : {
			type : String,
			coordinates : [
				Number,
				Number
			]
		},
		pickup_address : String,
		finished_date : Date,
		date : Date
	},
	finished : {
		estimate_distance : Number,
		estimate_time : Number,
		estimate_path : String
	},
	arrived : {
		estimate_distance : Number,
		estimate_path : String,
		estimate_time : Number
	},
	start : {
		zone_id : String,
		estimate_distance : String,
		estimate_time : String,
		estimate_path : String,
		real_location : {
			type : String,
			coordinates : [
				Number,
				Number
			]
		},
		marker_location : {
			type : String,
			coordinates : [
				Number,
				Number
			]
		},
		pickup_location : {
			type : String,
			coordinates : [
				Number,
				Number
			]
		},
		pickup_address : String,
		started_date : Date,
		starting_date : Date,
		date : Date
	},
	check_code : Number,
	statuses : Array,
	status : String,
	comments : String,
	concept : String,
	cost_center_id : String,
	alliance_id : String,
	alliance_user : String,
	alliance_father_id : String,
	guest : {
		color : String,
		model : String,
		plate : String,
		email : String,
		phone : String,
		name : String
	},
	passengers : Array,
	type_route : String,
	passenger_id : String,
	requester_id : String,
	user_pay_id : String,
	car_id : String,
	driver_id : String,
	reserve_hours : Number,
	zone_id : String,
	region_id : String,
	country_id : String,
	platform : {
		type : String,
		app_version : String,
		brand : String,
		version : Number,
		os : String
	},
	type_trip : String,
	type_service_id : String,
	feedback : {
		options : Array,
		value : Number
	},
	category : String,
	id : String,
	pendingTransactions : Array,
	accept : [
		{
			date : Date,
			location : {
				type : String,
				coordinates : [
					Number,
					Number
				]
			},
			radio : Number,
			estimate_distance :Number,
			estimate_path : Number,
			estimate_time : Number,
			driver_id : String,
			car_id : String
		}
	]
}, schemaOptions);

module.exports = mongoose.models.Trip||mongoose.model('Trip', tripSchema);