const mongoose = require('mongoose');
const constants = require('../functions/Contants');

var schemaOptions = {
  timestamps: true,
  toJSON: {
    virtuals: true
  },
  collection: constants.COLLECTIONS_ID+'miaguila_parameters_report'
};


var parametersSchema = new mongoose.Schema({
  reportType : String,
	fromNumber : Number,
	toNumber : Number,
	fromDate : Date,
	toDate : Date,
	paramIDs : Array,
	resultsLimit : Number
}, schemaOptions);

module.exports =mongoose.models.Parameters|| mongoose.model('Parameters', parametersSchema);