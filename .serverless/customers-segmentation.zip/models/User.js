const mongoose = require('mongoose');
const constants = require('../functions/Contants');

var schemaOptions = {
  timestamps: true,
  toJSON: {
    virtuals: true
  },
  collection: constants.COLLECTIONS_ID+'miaguila_users'
};


var userSchema = new mongoose.Schema({
  updatedAt: Date,
  createdAt: Date,
  active: Boolean,
  password_restore: String,
  swap: Number,
  balance: Number,
  promo_code_id: String,
  credit_card_id: String,
  access: Boolean,
  admin: Boolean,
  personal_info: {
    image: String,
    phone: String,
    lastname: String,
    firstname: String,
    phone_country: String
  },
  costs_centers_ids: Array,
  alliance_id: String,
  password: String,
  email: String,
  pendingTransactions: Number,
  type_user: Number,
  password_temp: Number,
  trips_due: Array,
  trips_report: {
    percent: Number,
    generated: Boolean,
    file_url: String,
    timeout: Date,
    expires: Date
  },
  referral_code: String,
  approved_phone: Boolean,
  approved_email: Boolean,
  routes: Array,
  referrals: Array,
  reportingHierarchy: Array
}, schemaOptions);

module.exports = mongoose.models.User||mongoose.model('User', userSchema);