const mongoose = require('mongoose');
const constants = require('../functions/Contants');


var schemaOptions = {
  timestamps: true,
  toJSON: {
    virtuals: true
  },
  collection: constants.COLLECTIONS_ID+'miaguila_report_results'
};


var parametersSchema = new mongoose.Schema({
    userid : String,
	count : Number,
}, schemaOptions);

module.exports = mongoose.models.ReportResults||mongoose.model('ReportResults', parametersSchema);