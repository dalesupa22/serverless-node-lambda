customers-segmetation

This is a serverless project using NodeJS and Lambda

---------------------DEPLOY IN LAMBDA-----------------------------------------------------------------

sls deploy


---------------------RUN LOCALLY-----------------------------------------------------------------

sls offline start


Author: dalesupa22
